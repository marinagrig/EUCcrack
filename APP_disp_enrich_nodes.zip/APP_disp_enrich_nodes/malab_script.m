load("x array 1.txt"); 
load("x array 2.txt");
load("y array 1.txt");
load("y array 2.txt");
load("z array 1.txt"); 
load("z array 2.txt");
xmin=min(min(x_array_1),min(x_array_2))
xmax=max(max(x_array_1),max(x_array_2))
ymin=min(min(y_array_1),min(y_array_2))
ymax=max(max(y_array_1),max(y_array_2))
zmin=min(min(z_array_1),min(z_array_2))
zmax=max(max(z_array_1),max(z_array_2))
xres=0.2;
yres=0.2;
zres=0.25;

figure(1)
scatter3(x_array_2,y_array_2,z_array_2, 'red', 'filled');
hold on
scatter3(x_array_1,y_array_1,z_array_1, 'blue', 'filled');
hold on
for x = xmin-2*xres:xres:xmax+2*xres
    for y = ymin-3*yres:yres:ymax+3*yres
        for z = zmin-2*zres:zres:zmax+2*zres
            Origin = [x,y,z] ;   % origin point 
            Size = [xres,yres,zres] ;  % your cube dimensions 
            plotcube2(Size,Origin,0,[0.9 0.9 0.9],0.3,[0.8 0.8 0.8]);   % use function plotcube 
            hold on
        end
    end
end
grid off
xlim([xmin-1 xmax+1]);
ylim([ymin-0.2 ymax+0.2]);
zlim([zmin-1 zmax+1]);
xlabel('x1') 
ylabel('x2') 
zlabel('x3')



