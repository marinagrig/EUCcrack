load("x array 1.txt"); 
load("x array 2.txt");
load("z array 1.txt");
load("z array 2.txt");
load("y array 1.txt"); 
load("y array 2.txt");
xmin=min(min(x_array_1),min(x_array_2))
xmax=max(max(x_array_1),max(x_array_2))
ymin=min(min(z_array_1),min(z_array_2))
ymax=max(max(z_array_1),max(z_array_2))
zmin=min(min(y_array_1),min(y_array_2))
zmax=max(max(y_array_1),max(y_array_2))
xres=0.2;
zres=0.2;
yres=0.25;

a = 1.6;
b = 0.7;
x_ellipse_1 = xmin:xres/50:xmax;
z_ellipse_1 = b*sqrt(1-(x_ellipse_1./a).^2);
y_ellipse_1 = -0.1;
x_ellipse_2 = xmin:xres/50:xmax;
z_ellipse_2 = -b*sqrt(1-(x_ellipse_2./a).^2);
y_ellipse_2 = -0.1;
figure(1)
scatter3(x_ellipse_1,z_ellipse_1+3,y_ellipse_1, 'green', 'filled');
hold on
scatter3(x_ellipse_2,z_ellipse_2+3,y_ellipse_2, 'green', 'filled');
hold on
scatter3(x_array_2,z_array_2,y_array_2, 'red', '*');
hold on
scatter3(x_array_1,z_array_1,y_array_1, 'blue', '*');
hold on
for x = xmin-xres:xres:xmax+xres
    for z = zmin-4*zres:zres:zmax+4*zres
        for y = ymin-yres:yres:ymax+yres
            Origin = [x,y,z] ;   % origin point 
            Size = [xres,yres,zres] ;  % your cube dimensions 
            plotcube2(Size,Origin,0,[0.9 0.9 0.9],0.3,[0.8 0.8 0.8]);   % use function plotcube 
            hold on
        end
    end
end
grid off
xlim([xmin-xres xmax+xres]);
zlim([zmin-0.5 zmax+0.5]);
ylim([ymin-yres ymax+yres]);
xlabel('x1') 
ylabel('x3') 
zlabel('x2')



